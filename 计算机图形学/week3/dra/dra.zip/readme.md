在该目录下打开命令行

![image-20230329160743543](./readme.assets/image-20230329160743543.png)