
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <math.h>
#include <string.h>

#include "/usr/include/readline/readline.h"
#include "/usr/include/readline/history.h"
#define MAX_LINE 100
#define MAX_AGRNUM 10
#define MAX_FILENAME_LENGTH 35
#define MAX_PIPELEN 10

// 从特定位置开始查看命令是否包含特定字符，并返回所在位置，否则返回-1
int parseOrder(char order[], int n, char c, int start)
{
    for (int i = start; i < n; i++)
    {
        if (order[i] == c)
        {
            return i;
        }
    }
    return -1;
}

void pip_function(int u);         // 执行多级管道命令
int pip[MAX_PIPELEN][2]; // 管道读写标识符
int pip_cnt = 0;         // 管道级数
char *prog[MAX_PIPELEN] = {NULL};

void sigcat(void)
{
    printf("%d get SIGQUIT\n", getpid());
    exit(0);
}

int main(void)
{

    // 自定义信号处理Start
    signal(SIGINT, SIG_IGN); // 父进程忽略SIGINT
    perror("SIGINT");
    signal(SIGQUIT, (__sighandler_t)sigcat); // 自定义父进程退出信号
    // 自定义信号处理End

    while (1)
    {
        int background = 0; // 命令是否放在后台执行
        pip_cnt = 0;

        // 调用readline接口实现命令获取、历史保存
        char *order = readline("COMMAND-> ");
        add_history(order);
        int n = strlen(order);

        char *exit_shell = ":quit";
        int if_exit = 1;
        for (int i = 0; i < 5; i++)
        {
            if (order[i] != exit_shell[i])
            {
                if_exit = 0;
            }
        }
        if (if_exit == 1)
        {
            return 0;
        }

        int fd;
        char outfile[MAX_FILENAME_LENGTH];   // 重定向输出文件
        char inputfile[MAX_FILENAME_LENGTH]; // 重定向输入文件（静态分配）

        char *arg[MAX_AGRNUM] = {NULL}; // 为指令的指针数组动态分配空间
        int cnt_arg = 0;                //解析出的指令个数

        int system_char, Space_pos;      // 记录功能符号位置
        int re_obj;        // 重定向对象
        int ifvis[MAX_LINE]; // 标记命令已解析部分
        memset(ifvis, 0, sizeof ifvis);

        if (parseOrder(order, n, '&', 0) == n - 1)
        {
            background = 1;
            ifvis[n - 1] = 1;
        }

        // >
        system_char = parseOrder(order, n, '>', 0);
        Space_pos = parseOrder(order, n, ' ', system_char);
        if (Space_pos < 0)
            Space_pos = n;
        Space_pos--;
        if (system_char > 0) //输出文件的重定向
        {
            strncpy(outfile, order + system_char + 1, Space_pos - system_char); // [system_char+1,Space_pos]
            for (int i = system_char; i <= Space_pos; i++)
            {
                ifvis[i] = 1; // 标记此命令已经被解析
            }
            outfile[Space_pos - system_char] = '\0';
            printf("redirect output to %s\n", outfile);
        }

        // <
        system_char = parseOrder(order, n, '<', 0);
        Space_pos = parseOrder(order, n, ' ', system_char);
        if (Space_pos < 0)
            Space_pos = n;
        Space_pos--;

        if (system_char > 0) // 输入文件重定向
        {
            strncpy(inputfile, order + system_char + 1, Space_pos - system_char);
            for (int i = system_char; i <= Space_pos; i++)
                ifvis[i] = 1;
            inputfile[Space_pos - system_char] = '\0';
            printf("redirect input to %s\n", inputfile);
        }

        // |
        int t = 0; // 查找起点
        // 把各级管道都存储在指针数组prog中
        while (1)
        {
            system_char = parseOrder(order, n, '|', t);
            if (system_char < 0)
            {
                break;
            }
            prog[pip_cnt] = (char *)malloc(sizeof(char) * MAX_FILENAME_LENGTH);
            memset(prog[pip_cnt], 0, sizeof prog[pip_cnt]);
            strncpy(prog[pip_cnt], order + t, system_char - t - 1); 
            for (int i = t; i <= system_char; i++)
                ifvis[i] = 1;
            t = system_char + 1;
            pip_cnt++;
        }
        if (fork() == 0)
        { // 子进程

            signal(SIGINT, SIG_DFL);

            if (parseOrder(order, n, '>', 0) >= 0)
            {
                fd = creat(outfile, S_IRWXU);
                close(1);
                dup(fd);
                close(fd);
            } /* 输出重定向 */

            if (parseOrder(order, n, '<', 0) >= 0)
            {
                fd = open(inputfile, O_RDONLY);
                if (fd < 0)
                {
                    fprintf(stderr, "can't find the file!\n");
                    exit(1);
                }
                close(0);
                dup(fd);
                close(fd);
            } /* 输入重定向 */

            /* 是否有形如 c1|c2|...|cn 的管道 */
            if (pip_cnt != 0)
            {
                pip_function(pip_cnt - 1);
            } /* 管道 */

            // 解析命令剩余部分，根据空格进行分割
            int arg_cnt = 0; // 参数个数
            for (int i = 0; i < n; i++)
            {
                if (ifvis[i] == 1 || (order[i] == ' '))
                {
                    continue;
                }
                arg[arg_cnt] = (char *)malloc(sizeof(char) * 100);

                Space_pos = parseOrder(order, n, ' ', i);
                if (Space_pos < 0)
                    Space_pos = n;
                strncpy(arg[arg_cnt], order + i, Space_pos - i);
                arg[arg_cnt][Space_pos - i] = '\0';
                i = Space_pos;
                arg_cnt++;
            }
            arg[arg_cnt] = NULL;

            execvp(arg[0], arg);
        }

        if (background == 0)
        {
            int status;
            wait(&status); // 父进程等待子进程结束
        }
        
        free(order); // readline为order分配动态内存
        for (int i = 0; i < cnt_arg; i++)
        {
            free(prog[i]);
        }
    }
}

void pip_function(int index)   // u为管道数
{
    pipe(pip[index]); // 建立无名管道pip

    if (fork() == 0)
    {
        // 标准输出至管道（架设管道）
        close(1);
        dup(pip[index][1]);
        close(pip[index][1]);
        close(pip[index][0]);

        if (index)
        {
            pip_function(index - 1); // 递归调用实现管道
        }
        else
        {
            execvp(prog[0], NULL);
        }
    }

    // 标准输入来自管道
    close(0);
    dup(pip[index][0]);
    close(pip[index][0]);
    close(pip[index][1]);

    if (pip_cnt - 1 != index) // 如果不是最后一个管道
    {
        execvp(prog[index + 1], NULL);
    }
}


